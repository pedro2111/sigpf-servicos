package br.gov.caixa.model.Rapidex.CaixaTem;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ClienteRequest {

	private String nuEmpresa;
	private String nuCPFCNPJ;
	private String dtNascimento;
	private String noCliente;
	private String deTipoPessoa;
	private String deEstadoCivil;
	private String coSexo;
	private String nuDdd;
	private String nuCelular;
	private String deEmail;
	private String deProfissao;
	private String nuCanal;
	private String nuAgencia;
	private boolean icMei;
	private Rg rg;
	private Endereco endereco;
	private Conta conta;

}