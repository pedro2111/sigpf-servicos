package br.gov.caixa.model.Rapidex.CaixaTem;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Rg {

	private String nuRG;
	private String deOrgaoEmissorRG;
	private String deUfOrgaoEmissorRG;
	private String dtEmissaoRG;

}
