package br.gov.caixa.model.Rapidex.CaixaTem;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAlias;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class IdentificadorVendaResponse {

	private String nuCPFCNPJ;
	private String deIdentificador;
	
	@JsonAlias(value= "produtos")
	private List<Planos> planos;

}
