package br.gov.caixa.model.Rapidex.Autorizacao;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class RapidexGetTokenRequest {

	private String client_id;
	private String client_secret;

}
