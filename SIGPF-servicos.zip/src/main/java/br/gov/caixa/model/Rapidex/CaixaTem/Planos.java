package br.gov.caixa.model.Rapidex.CaixaTem;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Planos {
	
	private String codigoProduto;
	private String plano;
	private String pagamento;
	private String descricao;
	private String valor;
	private String contratado;

}