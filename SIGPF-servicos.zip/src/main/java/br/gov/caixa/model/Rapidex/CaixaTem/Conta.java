package br.gov.caixa.model.Rapidex.CaixaTem;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Conta {

	private String nuAgencia;
	private String nuProduto;
	private String nuConta;
	private String nuDigitoConta;

}