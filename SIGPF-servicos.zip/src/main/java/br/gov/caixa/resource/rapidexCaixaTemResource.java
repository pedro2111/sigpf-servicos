package br.gov.caixa.resource;

import java.util.Date;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;

import br.gov.caixa.model.Rapidex.Autorizacao.Ping;
import br.gov.caixa.model.Rapidex.Autorizacao.RapidexGetRefreshTokenRequest;
import br.gov.caixa.model.Rapidex.Autorizacao.RapidexGetTokenRequest;
import br.gov.caixa.model.Rapidex.Autorizacao.RapidexResponse;
import br.gov.caixa.model.Rapidex.CaixaTem.ClienteRequest;
import br.gov.caixa.model.Rapidex.CaixaTem.ClienteResponse;
import br.gov.caixa.model.Rapidex.CaixaTem.IdentificadorPlanosClienteRequest;
import br.gov.caixa.model.Rapidex.CaixaTem.IdentificadorPlanosClienteResponse;
import br.gov.caixa.model.Rapidex.CaixaTem.IdentificadorVendaRequest;
import br.gov.caixa.model.Rapidex.CaixaTem.IdentificadorVendaResponse;
import br.gov.caixa.service.rapidexCaixaTemService;
import io.quarkus.security.Authenticated;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Path("/v1")
//@Authenticated
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class rapidexCaixaTemResource {

	@Inject
	@RestClient
	rapidexCaixaTemService rapidex;
	
	@ConfigProperty(name="rapidex.client_id")
	private String RAPIDEX_CLIENT_ID;
	
	@ConfigProperty(name="rapidex.client_secret")
	private String RAPIDEX_CLIENT_SECRET;	
	
	private RapidexResponse tokenRapidex;
	
	/*
	 * Recupera Token Rapidex
	 * 	Verifica se token está expirado 
	 * 			caso sim atualiza o token
	 * 			caso não devolve o token
	*/
	public String recuperarTokenRapidex() {
		RapidexGetTokenRequest r = new RapidexGetTokenRequest();
		r.setClient_id(RAPIDEX_CLIENT_ID);
		r.setClient_secret(RAPIDEX_CLIENT_SECRET);
		if (tokenRapidex != null) {
			if (isTokenExpirado()) {
				RapidexGetRefreshTokenRequest refresh = new RapidexGetRefreshTokenRequest();
				refresh.setAccess_token(tokenRapidex.getAccess_token());
				refresh.setRefresh_token(tokenRapidex.getRefresh_token());
				tokenRapidex = refreshTokenRapidex(refresh);
				return tokenRapidex.formataBearerToken();
			}
		}
		tokenRapidex = rapidex.getToken(r);
		return tokenRapidex.formataBearerToken();
	}

	/*
	 * Refresh Token Rapidex
	*/
    public RapidexResponse refreshTokenRapidex(RapidexGetRefreshTokenRequest r) {
    	r.setAccess_token(r.getAccess_token());
    	r.setRefresh_token(r.getRefresh_token());
    	return rapidex.refreshToken(r);
    }		

	/*
	 * Verifica se o token esta expirado
	*/
	private boolean isTokenExpirado() {
		DecodedJWT jwt = JWT.decode(tokenRapidex.getAccess_token());
		return jwt.getExpiresAt().before(new Date());
	}    
	
    @POST
    @Path("consultarMeusProdutos")
    @Tag(name = "Pós Venda", description = "Consultar produtos")
    @Operation(summary = "Envia os dados do cliente logado e retorna a lista de produtos que o usuário possui contratado")
    public ClienteResponse consultarClienteRapidex(ClienteRequest cliente) {
    	ClienteResponse  clienteResponse = rapidex.getCliente(recuperarTokenRapidex(), cliente);
    	clienteResponse.setNuCPFCNPJ(cliente.getNuCPFCNPJ());
    	return clienteResponse;
    }	
	
    @POST
    @Path("consultarPlanosDisponiveis")
    @Tag(name = "Pré Venda", description = "Consultar planos")
    @Operation(summary = "Envia os dados do usuário logado e recebe a lista de planos disponíveis")
    public IdentificadorPlanosClienteResponse consultarPlanosPorIdentificador(IdentificadorPlanosClienteRequest identificador) {
    	IdentificadorPlanosClienteResponse identificadorResponse = rapidex.getPlanos(recuperarTokenRapidex(), identificador);
    	identificadorResponse.setNuCPFCNPJ(identificador.getNuCPFCNPJ());
        return identificadorResponse;
    }		
    
    @POST
    @Path("gerarProposta")
    @Tag(name = "Venda", description = "Registrar venda")
    @Operation(summary = "Envia os dados para contratação")
    public IdentificadorVendaResponse ping(IdentificadorVendaRequest identificador) {
    	IdentificadorVendaResponse identificadorResponse = rapidex.getVenda(recuperarTokenRapidex(), identificador); 
    	identificadorResponse.setNuCPFCNPJ(identificador.getNuCPFCNPJ());
        return identificadorResponse;
    }
    
    @GET
    @Path("ping")
    public Ping ping() {
        return rapidex.ping();
    }    
}