package br.gov.caixa.model.Rapidex.CaixaTem;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class IdentificadorVendaRequest {

	
	private String nuEmpresa;
	private String nuCPFCNPJ;
	private String nuModalidade;
	private String nuTransacaoSeguridade;
	private String identificador;
	private String hashSeguranca;

}
