package br.gov.caixa.model.Rapidex.Autorizacao;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class RapidexResponse {

	private String access_token;
	private String refresh_token;
	private String created;
	private String expiration;
	private String expiration_refresh;

	public String formataBearerToken() {
		return "Bearer " + access_token;
	}
}
