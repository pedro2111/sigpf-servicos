package br.gov.caixa.service;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import br.gov.caixa.model.Rapidex.Autorizacao.Ping;
import br.gov.caixa.model.Rapidex.Autorizacao.RapidexGetRefreshTokenRequest;
import br.gov.caixa.model.Rapidex.Autorizacao.RapidexGetTokenRequest;
import br.gov.caixa.model.Rapidex.Autorizacao.RapidexResponse;
import br.gov.caixa.model.Rapidex.CaixaTem.ClienteRequest;
import br.gov.caixa.model.Rapidex.CaixaTem.ClienteResponse;
import br.gov.caixa.model.Rapidex.CaixaTem.IdentificadorPlanosClienteRequest;
import br.gov.caixa.model.Rapidex.CaixaTem.IdentificadorPlanosClienteResponse;
import br.gov.caixa.model.Rapidex.CaixaTem.IdentificadorVendaRequest;
import br.gov.caixa.model.Rapidex.CaixaTem.IdentificadorVendaResponse;

@Path("/")
@RegisterRestClient
public interface rapidexCaixaTemService {

    //Recupera Token Rapidex
    @POST
    @Path("/Autorizacao/token")
    public RapidexResponse getToken(RapidexGetTokenRequest rapidex);

    //Refresh Token Rapidex
    @POST
    @Path("/Autorizacao/refresh_token")
    public RapidexResponse refreshToken(RapidexGetRefreshTokenRequest r);
	
    //Ping servico Rapidex    
    @GET
    @Path("/Autorizacao/ping")
    public Ping ping(); 
	
	
    
	//Pos Venda
    @POST
    @Path("/CaixaTem/cliente")
    public ClienteResponse getCliente(@HeaderParam("Authorization") String tokenValue, ClienteRequest cliente);

	//Pré Venda
    @POST
    @Path("/CaixaTem/planos")
    public IdentificadorPlanosClienteResponse getPlanos(@HeaderParam("Authorization") String tokenValue, IdentificadorPlanosClienteRequest identificador);
    
	//Venda
    @POST
    @Path("/CaixaTem/contratar")
    public IdentificadorVendaResponse getVenda(@HeaderParam("Authorization") String tokenValue, IdentificadorVendaRequest identificador);
}